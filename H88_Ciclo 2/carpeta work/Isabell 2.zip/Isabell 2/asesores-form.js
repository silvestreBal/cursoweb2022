// SACANDO LOS DATOS DE LA TABLA
var tablaAsesores = localStorage.getItem("tablaAsesoresStorage");
tablaAsesores = JSON.parse(tablaAsesores);
if(tablaAsesores == null){
    var tablaAsesores =[];
} 

var idForm = localStorage.getItem("idForm");
idForm = JSON.parse(idForm);
if (idForm == null) {
    var idForm = 0;
}

cargarPagina();

function guardar(){
    
    Swal.fire({
        title: 'GUARDAR',
        html: 'DESEA GUARDAR CAMBIOS ?',
        showDenyButton: true,
        confirmButtonText: 'SI',
        denyButtonText: 'NO'
    }).then(
        (result) => {
            if (result.isConfirmed) {
    console.log("ENTRANDO A LA FUNCION GUARDAR...");

    var objAsesores = JSON.stringify({
        idAsesores: (idForm > 0) ? idForm : (tablaAsesores.length + 1),
        nombApellido  : document.getElementById("txtnombApellido").value,
        dni : document.getElementById("txtDni").value,
        telefono : document.getElementById("txtTelefono").value,
        estado : document.getElementById("cboEstado").value,

    });

    console.log(objAsesores);
    //GUARDANDO EN EL LOCALSTORAGE
    if(idForm > 0){// EDITAR PACIENTE
        for(const i in tablaAsesores){ // BUSCAR PACIENTE PARA EDITARLO
            var varAsesores = JSON.parse(tablaAsesores[i]);
            if(varAsesores.idAsesores == idForm){ // ENCONTRAR
                tablaAsesores[i] = objAsesores;
                break;
            }
        }
    }else{ // NUEVO PACIENTE
        tablaAsesores.push(objAsesores); // PARA NUEVO PACIENTE
    }

    localStorage.setItem("tablaAsesoresStorage", JSON.stringify(tablaAsesores));
    Swal.fire('Se guardaron los datos ! ', '', 'success').then(
        (result) => {
            window.location.replace("asesores.html");// REGRESAR A ASESORES.HTML
        }
    );
} else if(result.isDenied){
    Swal.fire('Cambios no Guardados', '', 'info');
}
}
);


}


function cargarPagina() {
    if (idForm > 0) {
        for( const i in tablaAsesores){// BUSCAR EL PACIENTE EN LA TABLA
            var varAsesores = JSON.parse(tablaAsesores[i]); // SACAMOS LA FILA 
            if(varAsesores.idAsesores == idForm){ // COMPARAMOS idAsesores CON EL IDFORM
                // PONIENDO LOS DATOS ENCONTRADOS EN EL FORMULARIO PARA SU EDICION
                document.getElementById("txtidAsesores").value = varAsesores.idAsesores;
                document.getElementById("txtnombApellido").value = varAsesores.nombApellido;
                document.getElementById("txtDni").value = varAsesores.dni;
                document.getElementById("txtTelefono").value = varAsesores.telefono;
                document.getElementById("cboEstado").value = varAsesores.estado;
                break;// DEJAR DE BUSCAR POR QUE SE ENCONTRO
            }
        }
    }
}