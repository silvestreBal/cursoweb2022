var tablaProfesor = localStorage.getItem("tablaProfesorStorage");
tablaProfesor = JSON.parse(tablaProfesor);
if (tablaProfesor == null) {
    var tablaProfesor = [];
}

listar();

function listar(){
    console.log("Ingresando a listar...");
    //console.log(tablaProfesor);

    var dataFila = '';

    // LLENANDO LA TABLA
    if(tablaProfesor.length > 0){ // SI LA TABLA NO ESTA VACIA
        for(const i in tablaProfesor){
            var varProfesor =  JSON.parse(tablaProfesor[i]);
            dataFila +="<tr>";
            dataFila +="<td>"+varProfesor.codigo+"</td>";
            dataFila +="<td>"+varProfesor.nombApellido+"</td>";
            dataFila +="<td>"+varProfesor.dni+"</td>";
            dataFila +="<td>"+varProfesor.telefono+"</td>";
            dataFila +="<td>"+varProfesor.correo+"</td>";
            dataFila +="<td>"+varProfesor.centro+"</td>";
            dataFila +="<td>"+varProfesor.curso+"</td>";
            dataFila +="<td>"+
                        "<button type='button' class='btn btn-warning' onclick='abrirForm("+varProfesor.codigo+")'>EDITAR</button>"+
                        "</td>";
            dataFila +="</tr>";

        }
        document.getElementById("dataProfesores").innerHTML = dataFila;
    }

}

function abrirForm(idForm){
    localStorage.setItem("idForm", JSON.stringify(idForm));
    window.location.replace("profesores-form.html");
}