// sacamos los datos de la tabla
var tablaAlumno = localStorage.getItem("tablaAlumnoStorage");
    tablaAlumno = JSON.parse(tablaAlumno);
    if(tablaAlumno ==null){
        var tablaAlumno =[];
    }

var idForm = localStorage.getItem("idForm");
idForm = JSON.parse(idForm);
if(idForm == null){
    var idForm = 0;
}

cargarPagina();

function guardar(){

    Swal.fire({
        title: 'GUARDAR',
        html: 'DESEA GUARDAR CAMBIOS?',
        showDenyButton:true,
        confirmButtonText: 'SI',
        denyButtonText: 'NO'
    }).then(
        (result) =>{
            if(result.isConfirmed){
                console.log("presiona guardar");
                var objAlumno =JSON.stringify({
                    idAlumno: (idForm > 0) ? idForm: (tablaAlumno.length +1),
                    nombreApellido: document.getElementById("txtNombreApellido").value,
                    edad: document.getElementById("txtEdad").value,
                    dni: document.getElementById("txtDni").value,
                    telefono: document.getElementById("txtTelefono").value,
                    direccion: document.getElementById("txtDireccion").value,
                    estado: document.getElementById("cboEstado").value,
                });
                console.log(objAlumno);
                // guardando en el localstorage
                if(idForm >0){  //editar alumno
                    for(const i in tablaAlumno){  //buscar alumno para editarlo
                        var varAlumno = JSON.parse(tablaAlumno[i]);
                        if(varAlumno.idAlumno == idForm){
                            tablaAlumno[i] = objAlumno;
                            break;
                        }
                    }
                }
                else{   //nuevo alumno
                    tablaAlumno.push(objAlumno);   //para nuevo alumno
                }
                localStorage.setItem("tablaAlumnoStorage", JSON.stringify(tablaAlumno));
                Swal.fire('Se guardaron los datos !', '', 'success').then(
                    (result) => {
                        window.location.replace("alumnos.html");  //regresar a alumnos.html
                    }
                );
            }
            else if(result.isDenied){
                Swal.fire('Cambios no guardados', '', 'info');
            }
        }
    );
}


function cargarPagina(){
    if(idForm >0){
        for(const i in tablaAlumno){  //buscar al alumno en la tabla
            var varAlumno = JSON.parse(tablaAlumno[i]);  // sacamos la fila
            if(varAlumno.idAlumno == idForm){  //comparamos idalumno con el idform
                // poniendo los datos encontrados en el formulario para su edicion
                document.getElementById("txtIdAlumno").value = varAlumno.idAlumno;
                document.getElementById("txtNombreApellido").value = varAlumno.nombreApellido;
                document.getElementById("txtEdad").value = varAlumno.edad;
                document.getElementById("txtDni").value = varAlumno.dni;
                document.getElementById("txtTelefono").value = varAlumno.telefono;
                document.getElementById("txtDireccion").value = varAlumno.direccion;
                document.getElementById("cboEstado").value = varAlumno.estado;

                break;
            }
        }
    }
}