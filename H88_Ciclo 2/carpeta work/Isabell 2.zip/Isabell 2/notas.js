var tablaalumnos = localStorage.getItem("tablaalumnosStorage");
tablaalumnos = JSON.parse(tablaalumnos);
if(tablaalumnos == null){
    var tablaalumnos = [];
}

buscar();

function buscar(){
    console.log("ingresando a listar");
    //console.log(tablaalumnos);

    var datafila = '';

    //LLENANDO LA TABLA
    if(tablaalumnos.length > 0 ){ //SI LA TABLA NO ESTÁ VACIA, LLENAR
        for(const i in tablaalumnos){
            //PARA ORDENAR
            var varnotas = JSON.parse (tablaalumnos[i])
            datafila +="<tr>";

            datafila +="<td>"+varnotas.idalumno+"</td>";
            datafila +="<td>"+varnotas.nombresapellido+"</td>";
            datafila +="<td>"+varnotas.ciclo+"</td>"
            datafila +="<td>"+varnotas.notas+"</td>"
            datafila +="<td>"+varnotas.telefono+"</td>"
            datafila +="<td>"+
                       "<button type='button' class='btn btn-warning' onclick='abrirform("+varnotas.idalumno+")'>EDITAR</button>"+
                       "</td>";
            datafila +="</tr>";

        }
        document.getElementById("datanotas").innerHTML = datafila
    }

}

//PARA EL BOTÓN NUEVO
function abrirform(idform){
    localStorage.setItem("idform",JSON.stringify(idform));
    window.location.replace("notas-form.html");
}