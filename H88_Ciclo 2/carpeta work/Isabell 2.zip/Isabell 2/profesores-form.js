//SACANDO LOS DATOS DE LA TABLA
var tablaProfesor = localStorage.getItem("tablaProfesorStorage");
tablaProfesor = JSON.parse(tablaProfesor);
if(tablaProfesor == null){
    var tablaProfesor = [];
}

var idForm = localStorage.getItem("idForm");
idForm = JSON.parse(idForm);
if (idForm == null) {
    var idForm = 0;
}

cargarPagina();

function guardar(){
    
    Swal.fire({
        title: 'GUARDAR',
        html: 'DESEA GUARDAR CAMBIOS ?',
        showDenyButton: true,
        confirmButtonText: 'SI',
        denyButtonText: 'NO'
    }).then(
        (result) => {
            if (result.isConfirmed) {
                console.log("PRESIONO GUARDAR...");
                var objProfesor = JSON.stringify({
                    codigo: (idForm > 0) ? idForm : (tablaProfesor.length + 1),
                    nombApellido : document.getElementById("txtNombApellido").value,
                    dni : document.getElementById("txtDni").value,
                    telefono : document.getElementById("txtTelefono").value,
                    correo : document.getElementById("txtCorreo").value,
                    centro : document.getElementById("txtCentro").value,
                    curso : document.getElementById("txtCurso").value,

                });

                console.log(objProfesor);
                //GUARDANDO EN EL LOCALSTORAGE
                if(idForm > 0){// EDITAR PROFESOR
                    for(const i in tablaProfesor){ // BUSCAR PROFESOR PARA EDITARLO
                        var varProfesor = JSON.parse(tablaProfesor[i]);
                        if(varProfesor.codigo == idForm){ // {ENCONTRAR
                            tablaProfesor[i] = objProfesor;
                            break;
                        }
                    }


                }else{ // NUEVO PROFESOR
                tablaProfesor.push(objProfesor); // PARA NUEVO PROFESOR
                }
                localStorage.setItem("tablaProfesorStorage", JSON.stringify(tablaProfesor));

                Swal.fire('Se guardaron los datos ! ', '', 'success').then(
                    (result) => {
                        window.location.replace("profesores.html");// REGRESAR A PROFESORES.HTML
                    }
                );
            }else if(result.isDenied){
            Swal.fire('Cambios no Guardados', '', 'info');
            }
        }
    );

}

function cargarPagina() {
    if (idForm > 0) {
        for( const i in tablaProfesor){// BUSCAR EL PROFESOR EN LA TABLA
            var varProfesor = JSON.parse(tablaProfesor[i]); // SACAMOS LA FILA 
            if(varProfesor.codigo == idForm){ // COMPARAMOS IDPROFESOR CON EL IDFORM
                // PONIENDO LOS DATOS ENCONTRADOS EN EL FORMULARIO PARA SU EDICION
                document.getElementById("txtCodigo").value = varProfesor.codigo;
                document.getElementById("txtNombApellido").value = varProfesor.nombApellido;
                document.getElementById("txtDni").value = varProfesor.dni;
                document.getElementById("txtTelefono").value = varProfesor.telefono;
                document.getElementById("txtCorreo").value = varProfesor.correo;
                document.getElementById("txtCentro").value = varProfesor.centro;
                document.getElementById("txtCurso").value = varProfesor.curso;
                break;// DEJAR DE BUSCAR POR QUE SE ENCONTRO
            }
        }
    }
}
