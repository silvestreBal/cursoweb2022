    //PARSE PARA DESARMAR Y STRINGIFY PARA ARMAR
    //PARA AGREGAR LOS DATOS A NOTAS.HTML
var tablaalumnos = localStorage.getItem("tablaalumnosStorage");
tablaalumnos = JSON.parse(tablaalumnos);
if(tablaalumnos == null){
 var tablaalumnos = [];
}

var idform = localStorage.getItem("idform");
idform = JSON.parse(idform);
if(idform == null){
    var idform = 0;
}

cargarpagina();

function guardar (){
    console.log("GUARDANDO")

    //JSON ES UNA INFORMACIÓN COMPACTA ENTRE LLAVES, TODO EL VALOR JSON ESTÁ GUARDADO EN LA VARIABLE 
    var objalumno = JSON.stringify({
        //agregar un +1 
        idalumno: (idform > 0)? idform : (tablaalumnos.length + 1),
        nombresapellido: document.getElementById("txtnombres").value,
        telefono: document.getElementById("txtelefono").value,
        notas: document.getElementById("txtnota").value,
        ciclo: document.getElementById("cbociclo").value,
    });

    console.log(objalumno);

    if(idform > 0){
        for(const i in tablaalumnos){
            var varalumno = JSON.parse(tablaalumnos[i]);
            if(varalumno.idalumno == idform){
                tablaalumnos[i] = objalumno;
                break;
            }
        }

    }else{
        tablaalumnos.push(objalumno);
    }

    localStorage.setItem("tablaalumnosStorage",JSON.stringify(tablaalumnos));

    window.location.replace("notas.html")
}
function cargarpagina(){
    if(idform>0){
        for(const i in tablaalumnos){//BUSCAR EL ALUMNO EN LA TABLA
            var varalumno = JSON.parse(tablaalumnos[i]);
            if(varalumno.idalumno == idform){//COMPARAMOS IDALUMNO CON EL IDFORM
                document.getElementById("txtUsuario").value = varalumno.idalumno;
                document.getElementById("txtnombres").value = varalumno.nombresapellido;
                document.getElementById("txtelefono").value = varalumno.telefono;
                document.getElementById("txtnota").value = varalumno.notas;
                document.getElementById("cbociclo").value = varalumno.ciclo;
                break;
            }
        }
    }
}