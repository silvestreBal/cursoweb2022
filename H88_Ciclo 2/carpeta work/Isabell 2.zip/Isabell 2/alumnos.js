
var tablaAlumno = localStorage.getItem("tablaAlumnoStorage");
tablaAlumno = JSON.parse(tablaAlumno);
if(tablaAlumno == null){
    var tablaAlumno = [];
}

listar();

function listar(){
    console.log("ingresando a listar")

    var dataFila ='';

    //lenando la tabla
    if(tablaAlumno.length > 0){    // si la tabla esta vacia
        for(const i in tablaAlumno){

            var varAlumno = JSON.parse(tablaAlumno[i]);
            dataFila +="<tr>";
            dataFila +="<td>"+ varAlumno.idAlumno+"</td>";
            dataFila +="<td>"+ varAlumno.nombreApellido+"</td>";
            dataFila +="<td>"+ varAlumno.edad+"</td>";
            dataFila +="<td>"+ varAlumno.dni+"</td>";
            dataFila +="<td>"+ varAlumno.telefono+"</td>";
            dataFila +="<td>"+ varAlumno.direccion+"</td>";
            dataFila +="<td>"+ varAlumno.estado+"</td>";
            dataFila +="<td>"+
                        "<button type='button' class='btn btn-warning' onclick='abrirForm("+varAlumno.idAlumno+")'>EDITAR</button>"+
                        "</td>";
            dataFila +="</tr>";
        }
        document.getElementById("dataAlumnos").innerHTML = dataFila;
    }
}


function abrirForm(idForm){
    localStorage.setItem("idForm", JSON.stringify(idForm));
    window.location.replace("alumnos-form.html");
}