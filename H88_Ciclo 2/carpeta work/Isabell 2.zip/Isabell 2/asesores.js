var tablaAsesores = localStorage.getItem("tablaAsesoresStorage");
tablaAsesores = JSON.parse(tablaAsesores);
if (tablaAsesores == null) {
    var tablaAsesores = [];
}

listar();

function listar(){
    console.log("Ingresando a listar...");
    //console.log(tablaAsesores);

    var dataFila = '';

    // LLENANDO LA TABLA
    if(tablaAsesores.length > 0){ // SI LA TABLA NO ESTA VACIA
        for(const i in tablaAsesores){
            var varAsesores =  JSON.parse(tablaAsesores[i]);
            dataFila +="<tr>";
            dataFila +="<td>"+varAsesores.idAsesores+"</td>";
            dataFila +="<td>"+varAsesores.nombApellido+"</td>";
            dataFila +="<td>"+varAsesores.dni+"</td>";
            dataFila +="<td>"+varAsesores.telefono+"</td>";
            dataFila +="<td>"+varAsesores.estado+"</td>";
            dataFila +="<td>"+
                       "<button type='button' class='btn btn-warning' onclick='abrirForm("+varAsesores.idAsesores+")'>EDITAR</button>"+
                       "</td>";
            dataFila +="</tr>";

        }
        document.getElementById("dataAsesores").innerHTML = dataFila;
    }

}

function abrirForm(idForm){
    localStorage.setItem("idForm", JSON.stringify(idForm));
    window.location.replace("asesores-form.html");
}